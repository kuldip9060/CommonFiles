//
//  LogsDB.swift
//  LocationTest
//
//  Created by Angel Ignatov on 10/27/15.
//  Copyright © 2015 Aggressione. All rights reserved.
//

import CoreData

@objc(LogsDB)
class LogsDB: NSManagedObject {
    @NSManaged var log: String
    @NSManaged var date: String    
    
    static var ENTITY_NAME: String = "LogsDB"
    
    class func save(_ log: String) {
        
        let db = CoreDataHelper.getContext(LogsDB.ENTITY_NAME, inBackground: false)
        
        let logsDB: LogsDB = LogsDB(entity: db.entity, insertInto: db.context)
        
        let currentDateTime = Date()
        let formatter = DateFormatter()
        formatter.timeStyle = DateFormatter.Style.medium
        formatter.dateStyle = DateFormatter.Style.medium
        
        logsDB.date = formatter.string(from: currentDateTime)
        logsDB.log = log
        db.cdh.saveContext(db.context)
    }
    
    class func getAllData() -> [LogsDB] {
        
        let db = CoreDataHelper.getContext(LogsDB.ENTITY_NAME, inBackground: false)
        
        let request = NSFetchRequest<NSFetchRequestResult>(entityName: LogsDB.ENTITY_NAME)
        request.returnsObjectsAsFaults = false
        request.sortDescriptors = [NSSortDescriptor(key: "date", ascending: false)]
        
        var results: [LogsDB] = [LogsDB]()
        
        do {
            try results = db.context.fetch(request) as! [LogsDB]
        } catch let error as NSError {
            print(error.localizedDescription)
        }
        
        return results
    }

}
