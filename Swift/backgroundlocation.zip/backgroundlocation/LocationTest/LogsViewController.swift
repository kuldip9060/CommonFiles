//
//  LogsViewController.swift
//  LocationTest
//
//  Created by Angel Ignatov on 10/27/15.
//  Copyright © 2015 Aggressione. All rights reserved.
//

import UIKit

class LogsViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    
    var data: [LogsDB] = [LogsDB]()
    
    @IBOutlet var tableView: UITableView!
    override func viewDidLoad() {
        super.viewDidLoad()
        
        refreshData()
    }
    
    func refreshData() {
        data = LogsDB.getAllData()
        tableView.reloadSections(IndexSet(integer: 0), with: UITableViewRowAnimation.fade)
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return data.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
                
        let cell = UITableViewCell(style: UITableViewCellStyle.subtitle, reuseIdentifier: "Cell")
        
        let row: LogsDB = data[indexPath.row]
        
        cell.textLabel?.numberOfLines = 0
        cell.textLabel?.text = nil
        
        cell.detailTextLabel?.numberOfLines = 0
        cell.detailTextLabel?.text = "date: \(row.date) \n\(row.log)"
        
        return cell
        
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
}
